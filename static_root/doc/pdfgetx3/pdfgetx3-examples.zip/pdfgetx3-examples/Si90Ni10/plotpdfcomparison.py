#!/usr/bin/env python

from diffpy.pdfgetx import loadData
from pylab import *

r0, g0 = loadData('si90ni10_300k_nor_1-6-pdfgetx2.gr', usecols=(0, 1)).T
r1, g1 = loadData('si90ni10_300k_nor_1-6-pdfgetx3.gr').T
g1s = max(g0) / max(g1) * g1
gds = g0 - interp(r0, r1, g1s)
plot(r0, g0, label='PDFGetX2, Qmax=27/A')
plot(r1, g1s, label='PDFGetX3, Qmax=26/A, scaled')
plot(r0, gds - 4, label='difference curve')
title('mixture Si0.9-Ni0.1')
xlabel('r (A)')
ylabel('G (A$^{-2}$)')
legend(prop=dict(size=11))
xlim(0, 30)
show()
